@echo off
cd /d "%~dp0"
start "" /b "runtime\pythonw.exe" -m sc1.manager.effect_lab_launch
