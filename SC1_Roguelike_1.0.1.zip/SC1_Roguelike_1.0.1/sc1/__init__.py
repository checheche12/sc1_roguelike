"""StarCraft campaign roguelike; no SC2 dependencies."""

__version__ = "1.0.1"
RELEASE_CHANNEL = "stable"
